var searchData=
[
  ['delegate',['delegate',['../interface_s_i_m_charge_card_model.html#a21055a4b99124afa09e838a3d3918795',1,'SIMChargeCardModel::delegate()'],['../interface_s_i_m_charge_card_view_controller.html#ac3c5f2283a00a7e71f0f544390511381',1,'SIMChargeCardViewController::delegate()']]]
];
