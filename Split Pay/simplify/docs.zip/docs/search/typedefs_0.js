var searchData=
[
  ['cardtokencompletionhandler',['CardTokenCompletionHandler',['../interface_s_i_m_simplify.html#adfa0ea4b604f2fd39a101931382c25e1',1,'SIMSimplify']]]
];
