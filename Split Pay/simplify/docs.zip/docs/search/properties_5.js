var searchData=
[
  ['islivemode',['isLiveMode',['../interface_s_i_m_simplify.html#a05648565a5713a55a45fa82b41dd7e95',1,'SIMSimplify']]]
];
