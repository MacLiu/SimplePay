var searchData=
[
  ['maxcardlength',['maxCardLength',['../interface_s_i_m_card_type.html#abb0047158408b19de59b23c916591f70',1,'SIMCardType']]],
  ['mincardlength',['minCardLength',['../interface_s_i_m_card_type.html#aa631192ded99fc66d62e6be3ce1758f6',1,'SIMCardType']]]
];
