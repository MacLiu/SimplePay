var interface_s_i_m_address =
[
    [ "initWithName:addressLine1:addressLine2:city:state:zip:", "interface_s_i_m_address.html#aad2a41054ea983e4a634edd0b523eaac", null ],
    [ "addressLine1", "interface_s_i_m_address.html#ad3168454b0290b906aba941ae39487a3", null ],
    [ "addressLine2", "interface_s_i_m_address.html#a2ba69d434e2d044e0ed27670533a1002", null ],
    [ "city", "interface_s_i_m_address.html#ad0319fc60cf0b0fc7e722ca4c8c8d533", null ],
    [ "country", "interface_s_i_m_address.html#a4bea61951de254eeda26e8ea2466b5ce", null ],
    [ "name", "interface_s_i_m_address.html#a332d89cf436373e3f080528aa780dd02", null ],
    [ "state", "interface_s_i_m_address.html#a633a3745dfb38e77c381bb195e9f1fd5", null ],
    [ "zip", "interface_s_i_m_address.html#aec44a0a4956373e46f35befe35dd3e67", null ]
];