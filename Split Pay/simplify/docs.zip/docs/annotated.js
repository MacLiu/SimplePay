var annotated =
[
    [ "SIMAddress", "interface_s_i_m_address.html", "interface_s_i_m_address" ],
    [ "SIMCardType", "interface_s_i_m_card_type.html", "interface_s_i_m_card_type" ],
    [ "SIMChargeCardModel", "interface_s_i_m_charge_card_model.html", "interface_s_i_m_charge_card_model" ],
    [ "<SIMChargeCardModelDelegate>", "protocol_s_i_m_charge_card_model_delegate-p.html", "protocol_s_i_m_charge_card_model_delegate-p" ],
    [ "SIMChargeCardViewController", "interface_s_i_m_charge_card_view_controller.html", "interface_s_i_m_charge_card_view_controller" ],
    [ "<SIMChargeCardViewControllerDelegate>", "protocol_s_i_m_charge_card_view_controller_delegate-p.html", "protocol_s_i_m_charge_card_view_controller_delegate-p" ],
    [ "SIMDigitVerifier", "interface_s_i_m_digit_verifier.html", "interface_s_i_m_digit_verifier" ],
    [ "SIMLuhnValidator", "interface_s_i_m_luhn_validator.html", "interface_s_i_m_luhn_validator" ],
    [ "SIMProductViewController", "interface_s_i_m_product_view_controller.html", null ],
    [ "SIMSimplify", "interface_s_i_m_simplify.html", "interface_s_i_m_simplify" ]
];