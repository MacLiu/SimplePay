var files =
[
    [ "SimplifyMerchantSDK", "dir_956c7b2a06e6eded3bea26e68dd867c3.html", "dir_956c7b2a06e6eded3bea26e68dd867c3" ],
    [ "SimplifySDKSampleApp", "dir_cf230b6758a2d672ee447b30203c2ac0.html", "dir_cf230b6758a2d672ee447b30203c2ac0" ]
];