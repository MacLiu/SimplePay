var protocol_s_i_m_charge_card_model_delegate_p =
[
    [ "tokenFailedWithError:", "protocol_s_i_m_charge_card_model_delegate-p.html#af746683601a86985246a348071a01a40", null ],
    [ "tokenProcessed:", "protocol_s_i_m_charge_card_model_delegate-p.html#a34e234af5f832cabf1ce822c7ed7c86a", null ]
];