var interface_s_i_m_simplify =
[
    [ "CardTokenCompletionHandler", "interface_s_i_m_simplify.html#adfa0ea4b604f2fd39a101931382c25e1", null ],
    [ "createCardTokenWithExpirationMonth:expirationYear:cardNumber:cvc:address:completionHander:", "interface_s_i_m_simplify.html#af93e60941fc96eb9a1e1799c30b8f3d1", null ],
    [ "initWithPublicKey:error:", "interface_s_i_m_simplify.html#ac4a31c5eed5acbc28fca394b93df22aa", null ],
    [ "isLiveMode", "interface_s_i_m_simplify.html#a05648565a5713a55a45fa82b41dd7e95", null ]
];